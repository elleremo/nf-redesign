import HystModal from './hystmodal';
import 'element-closest-polyfill';
import './hystmodal.css';
global.HystModal = HystModal;